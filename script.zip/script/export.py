import boto3
import urllib


def create_pokemon_table(dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb', endpoint_url="http://localhost:8000")

    table = dynamodb.create_table(
        TableName='Pokemon',
        KeySchema=[
            {
                'AttributeName': 'number',
                'KeyType': 'HASH'  
            },
            {
                'AttributeName': 'name',
                'KeyType': 'RANGE'  
            },
            {
                'AttributeName': 'power',
                'KeyType': 'RANGE'  
            },
            {
                'AttributeName': 'generation',
                'KeyType': 'RANGE'  
            }
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'number',
                'AttributeType': 'N'
            },
            {
                'AttributeName': 'name',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'power',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'generation',
                'AttributeType': 'N'
            },

        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 10,
            'WriteCapacityUnits': 10
        }
    )
    

def put_pokemon(number, name, power, generation, dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb', endpoint_url="http://localhost:8000")

    table = dynamodb.Table('Pokemon')
    response = table.put_item(
       Item={
            'number': number,
            'name': name,            
            'power': power,
            'generation': generation
            
        }
    )
 
s3 = boto3.client('s3')
obj = s3.get_object(Bucket = 'assignment-terraform', Key = 'Pokemon')
lines = obj['Body'].read().decode("utf-8").split("\r\n")


try:
	create_pokemon_table(0)
	for line in lines:
		data = line.split(",")
		put_pokemon(data[0],data[1],data[2],data[3],0)
except:
	print("")
